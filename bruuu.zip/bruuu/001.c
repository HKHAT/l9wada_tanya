#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char **tokens;
size_t tk_pos;
size_t tk_size;

void add_token(char *str)
{
    if (tk_size == 0)
    {
        tk_size = 10;
        tokens = calloc(tk_size + 1, sizeof(char *));
    }
    else if (tk_pos + 1 == tk_size)
    {
        char **tmp = calloc(tk_size * 2, sizeof(char *));
        memcpy(tmp, tokens, tk_size * sizeof(char *));
        free(tokens);
        tk_size *= 2;
        tokens = tmp;
    }
    tokens[tk_pos++] = str;
}
#include <stdbool.h>
void tokenize(char *line)
{
    int i = 0;
    while (line[i])
    {
        if(isspace(line[i]))
        {
            i++;
        }
        else if (strchr("<>", line[i]))
        {
            if (line[i] == line[i + 1]) // >> << 
            {
                char *str = calloc(3, sizeof(char));
                strncpy(str, line + i, 2);
                add_token(str);
                i++;
            }
            else // > <
            {
                char *str = calloc(2, sizeof(char));
                str[0] = line[i];
                add_token(str);
            }
            i++;
        }
        else if (strchr("|&()", line[i]))
        {
            char *str = calloc(2, sizeof(char));
            str[0] = line[i];
            add_token(str);
            i++;
        }
        else
        {
            /* "'ls"' */
            int s = i;
            bool dquote = 0;
            bool squote = 0;
            while (line[i])
            {
                printf("<%c>\n", line[i]);
                if (line[i] == '\'' && !dquote)
                {
                    squote = !squote;
                    i++;
                }
                else if (line[i] == '\"' && !squote)
                {
                    dquote = !dquote;
                    i++;
                }
                else if (!squote && !dquote && (strchr("&|<>()", line[i]) || isspace(line[i])))
                    break;
                else
                    i++;
            }
            if(squote || dquote)
            {
                printf("Syntax error\n");
                exit(1);
            }
            char *str = calloc(i - s + 1, sizeof(char));
            strncpy(str, line + s, i - s);
            add_token(str);
        }
    }
}

void check(char *res, int *j_ptr, int *size_ptr)
{
    int j = *j_ptr;
    int size = *size_ptr;

    if (j == size)
    {
        char *tmp = calloc(size * 2, sizeof(char));
        strcpy(tmp, res);
        free(res);
        res = tmp;
        size *= 2;
    }

    *j_ptr = j;
    *size_ptr = size;
}

char *expand(char *line)
{
    int i = 0;
    int j = 0;
    int size = 10;
    char *res = calloc(size, sizeof(char));
    while (line[i])
    {
        if (line[i] == '"')
        {
            i++;
            while (line[i] != '"')
            {
                res[j++] = line[i++];
                check(res, &j, &size);
            }
            i++;
        }
        else if (line[i] == '\'')
        {
            i++;
            while (line[i] != '"')
            {
                res[j++] = line[i++];
                check(res, &j, &size);
            }
            i++;
        }
        else
        {
            res[j++] = line[i++];
            check(res, &j, &size);
        }
    }
    return res;
}

int main()
{
    /*
    "">''
    << """l"
    >>"""l"
    ">>"
    */
    // char *str = strdup("\"l\"s"); // "l"s
    // char *res = expand(str);
    // printf("<%s>\n", res);
    // free(str);
    // free(res);
    char *str = strdup("ls << \"\"\"l\" ");
    tokenize(str);
    int i = 0;
    while (i < tk_pos)
    {
        printf("[%s] expand to [%s]\n", tokens[i], expand(tokens[i]));
        i++;
    }
}