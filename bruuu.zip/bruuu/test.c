#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef enum {
    TOKEN_WORD,
    TOKEN_PIPE,
    TOKEN_REDIRECT_IN,
    TOKEN_REDIRECT_OUT,
    TOKEN_APPEND_OUT,
    TOKEN_HEREDOC,
    TOKEN_BACKGROUND,
    TOKEN_AND,
    TOKEN_OR,
    TOKEN_LPR,
    TOKEN_RPR,
    TOKEN_END,
    TOKEN_AMBIGUOUS
} TokenType;

typedef struct {
    TokenType type;
    char *value;
} Token;

typedef struct {
    int in_quotes;
    char quote_char;
    int buffer_index;
    int double_quotes;
    int expandit;
    char buffer[1024];
    char *start;
    char *expanded_value;
    int flag;
    void *env;
} QuoteWordParserState;

void add_token(Token *tokens, int *num_tokens, TokenType type, const char *value) {
    tokens[*num_tokens].type = type;
    tokens[*num_tokens].value = strdup(value);
    (*num_tokens)++;
}

void skip_whitespace(const char **p) {
    while (isspace((unsigned char)**p)) {
        (*p)++;
    }
}

int handle_quotes(const char **p, QuoteWordParserState *state) {
    if (**p == '\\' && *(*p + 1) != '\0') {
        state->buffer[state->buffer_index++] = *(*p + 1);
        (*p) += 2;
        return 1;
    } else if ((**p == '"' || **p == '\'') && (state->in_quotes == 0 || **p == state->quote_char)) {
        if (state->in_quotes == 0) {
            state->in_quotes = 1;
            state->quote_char = **p;
        } else if (**p == state->quote_char) {
            state->in_quotes = 0;
            state->quote_char = '\0';
        }
        (*p)++;
        return 1;
    }
    return 0;
}

void handle_quotes_and_words(const char **p, Token *tokens, int *num_tokens, QuoteWordParserState *state) {
    state->buffer_index = 0;
    while (**p != '\0' && (state->in_quotes || (!isspace((unsigned char)**p) && **p != '|' 
    && **p != '<' && **p != '>' && **p != '&' && **p != '(' && **p != ')'))) {
        if (handle_quotes(p, state)) {
            continue;
        } else {
            state->buffer[state->buffer_index++] = *(*p)++;
        }
    }
    state->buffer[state->buffer_index] = '\0';

    if (state->buffer_index > 0 || (state->in_quotes == 0 && state->quote_char != '\0')) {
        char *buffer_copy = strdup(state->buffer);
        add_token(tokens, num_tokens, TOKEN_WORD, buffer_copy);
        free(buffer_copy);
    }
}

void handle_special_characters(const char **p, Token *tokens, int *num_tokens) {
    TokenType type = TOKEN_WORD;
    char special[4];

    if (**p == '|' || **p == '<' || **p == '>' || **p == '&') {
        special[0] = **p;
        special[1] = '\0';
        if (**p == '|' && *(*p + 1) != '|') {
            type = TOKEN_PIPE;
        } else if (**p == '|' && *(*p + 1) == '|') {
            type = TOKEN_OR;
            special[1] = '|';
            special[2] = '\0';
            (*p)++;
        } else if (**p == '&' && *(*p + 1) == '&') {
            type = TOKEN_AND;
            special[1] = '&';
            special[2] = '\0';
            (*p)++;
        } else if (**p == '&') {
            type = TOKEN_BACKGROUND;
        } else if (**p == '>') {
            if (*(*p + 1) == '>') {
                type = TOKEN_APPEND_OUT;
                special[1] = '>';
                special[2] = '\0';
                (*p)++;
            } else {
                type = TOKEN_REDIRECT_OUT;
            }
        } else if (**p == '<') {
            if (*(*p + 1) == '<') {
                type = TOKEN_HEREDOC;
                special[1] = '<';
                special[2] = '\0';
                (*p)++;
            } else {
                type = TOKEN_REDIRECT_IN;
            }
        }
        add_token(tokens, num_tokens, type, special);
        (*p)++;
        skip_whitespace(p);
        if (**p == '"' || **p == '\'') {
            QuoteWordParserState state = {0};
            handle_quotes_and_words(p, tokens, num_tokens, &state);
        }
        return;
    } else if (**p == '(') {
        type = TOKEN_LPR;
        special[0] = '(';
        special[1] = '\0';
        add_token(tokens, num_tokens, type, special);
        (*p)++;
    } else if (**p == ')') {
        type = TOKEN_RPR;
        special[0] = ')';
        special[1] = '\0';
        add_token(tokens, num_tokens, type, special);
        (*p)++;
    }
}

int lex(const char *input, Token *tokens, int *num_tokens, void *env) {
    const char *p = input;
    QuoteWordParserState state;
    state.in_quotes = 0;
    state.quote_char = '\0';
    state.buffer_index = 0;
    state.double_quotes = 0;
    state.expandit = 0;
    state.flag = 0;
    state.start = NULL;
    state.env = env;
    memset(state.buffer, 0, sizeof(state.buffer));

    while (*p) {
        skip_whitespace(&p);
        handle_special_characters(&p, tokens, num_tokens);
        handle_quotes_and_words(&p, tokens, num_tokens, &state);
    }

    // Check if quotes are not closed
    if (state.in_quotes) {
        printf("Syntax error: unclosed quote '%c'\n", state.quote_char);
        return 1;
    }

    add_token(tokens, num_tokens, TOKEN_END, "");
    return 0;
}

int main() {
    const char *input = "<< \"\"";
    Token tokens[256];
    int num_tokens = 0;

    int result = lex(input, tokens, &num_tokens, NULL);

    if (result == 0) {
        for (int i = 0; i < num_tokens; i++) {
            printf("Token %d: Type=%d, Value=%s\n", i, tokens[i].type, tokens[i].value);
            free(tokens[i].value);
        }
    }

    return result;
}

